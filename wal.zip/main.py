from fastapi import FastAPI, HTTPException, Depends
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from jose import JWTError, jwt
from pydantic import BaseModel
import asyncio
import time
import json
import os
from typing import Dict, Optional

app = FastAPI(
    title="PyKV - Secure In-Memory Key-Value Store",
    version="4.1.0"
)

# =============================
# CONFIG
# =============================
SECRET_KEY = "supersecretkey123"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_SECONDS = 3600
WAL_FILE = "wal.log"

# =============================
# SIMPLE USER DB (NO BCRYPT)
# =============================
fake_users_db = {
    "admin": {
        "username": "admin",
        "password": "admin123",
        "full_name": "Administrator",
        "email": "admin@example.com",
        "roles": ["admin", "user"],
        "preferences": {"theme": "dark", "notifications": True},
        "recent_activity": [
            {"action": "created_key", "key": "welcome", "time": 0}
        ]
    }
}

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="auth/login")

# =============================
# STORE
# =============================
store: Dict[str, Dict[str, Optional[float]]] = {}
lock = asyncio.Lock()


# =============================
# MODELS
# =============================
class Item(BaseModel):
    key: str
    value: str
    ttl: Optional[int] = None


# =============================
# AUTH FUNCTIONS
# =============================
def authenticate_user(username: str, password: str):
    user = fake_users_db.get(username)
    if not user or user["password"] != password:
        return False
    return user


def create_access_token(data: dict):
    to_encode = data.copy()
    expire = time.time() + ACCESS_TOKEN_EXPIRE_SECONDS
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)


async def get_current_user(token: str = Depends(oauth2_scheme)):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise HTTPException(status_code=401, detail="Invalid token")
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

    user = fake_users_db.get(username)
    if user is None:
        raise HTTPException(status_code=401, detail="User not found")
    return user


# =============================
# WAL FUNCTIONS
# =============================
def write_wal(operation: dict):
    with open(WAL_FILE, "a") as f:
        f.write(json.dumps(operation) + "\n")
        f.flush()
        os.fsync(f.fileno())


def replay_wal():
    if not os.path.exists(WAL_FILE):
        return

    with open(WAL_FILE, "r") as f:
        for line in f:
            operation = json.loads(line.strip())

            if operation["type"] == "SET":
                store[operation["key"]] = {
                    "value": operation["value"],
                    "expiry": operation["expiry"]
                }

            elif operation["type"] == "DELETE":
                store.pop(operation["key"], None)


# =============================
# BACKGROUND TTL CLEANUP
# =============================
async def expiry_cleanup():
    while True:
        await asyncio.sleep(5)
        async with lock:
            current_time = time.time()
            expired_keys = [
                key for key, data in store.items()
                if data["expiry"] is not None and current_time > data["expiry"]
            ]
            for key in expired_keys:
                del store[key]


# =============================
# STARTUP EVENT
# =============================
@app.on_event("startup")
async def startup_event():
    replay_wal()
    asyncio.create_task(expiry_cleanup())

# Serve frontend static files from the project root under /static
app.mount("/static", StaticFiles(directory="."), name="static")


# =============================
# AUTH ROUTE
# =============================
@app.post("/auth/login")
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    user = authenticate_user(form_data.username, form_data.password)
    if not user:
        raise HTTPException(status_code=401, detail="Incorrect username or password")

    access_token = create_access_token(data={"sub": user["username"]})
    # Do not return the password field
    user_public = {k: v for k, v in user.items() if k != "password"}
    return {"access_token": access_token, "token_type": "bearer", "user": user_public}


# =============================
# ROOT
# =============================
@app.get("/")
async def root():
    return FileResponse("index.html")


# Return current user's public profile
@app.get("/auth/me")
async def me(user: dict = Depends(get_current_user)):
    user_public = {k: v for k, v in user.items() if k != "password"}
    return user_public


# =============================
# HEALTH
# =============================
@app.get("/health")
async def health():
    return {
        "status": "healthy",
        "total_keys": len(store)
    }


# =============================
# PROTECTED KV ROUTES
# =============================
@app.post("/kv")
async def set_key(item: Item, user: dict = Depends(get_current_user)):
    expiry_time = None
    if item.ttl:
        expiry_time = time.time() + item.ttl

    operation = {
        "type": "SET",
        "key": item.key,
        "value": item.value,
        "expiry": expiry_time
    }

    async with lock:
        write_wal(operation)
        store[item.key] = {
            "value": item.value,
            "expiry": expiry_time
        }

    return {"message": "Key stored successfully"}


@app.get("/kv/{key}")
async def get_key(key: str, user: dict = Depends(get_current_user)):
    async with lock:
        if key not in store:
            raise HTTPException(status_code=404, detail="Key not found")

        data = store[key]

        if data["expiry"] and time.time() > data["expiry"]:
            del store[key]
            raise HTTPException(status_code=404, detail="Key expired")

    return {"key": key, "value": data["value"]}


@app.delete("/kv/{key}")
async def delete_key(key: str, user: dict = Depends(get_current_user)):
    async with lock:
        if key not in store:
            raise HTTPException(status_code=404, detail="Key not found")

        write_wal({"type": "DELETE", "key": key})
        del store[key]

    return {"message": "Key deleted successfully"}
